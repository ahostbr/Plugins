#pragma once

#include "SOTS_KEM_Types.h"
