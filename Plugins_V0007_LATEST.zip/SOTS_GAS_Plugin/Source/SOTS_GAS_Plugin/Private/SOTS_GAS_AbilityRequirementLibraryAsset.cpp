#include "SOTS_GAS_AbilityRequirementLibraryAsset.h"

