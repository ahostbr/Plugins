
#include "LightProbePluginModule.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_MODULE(FLightProbePluginModule, LightProbePlugin)

void FLightProbePluginModule::StartupModule()
{
}

void FLightProbePluginModule::ShutdownModule()
{
}
