#include "SOTS_StealthConfigDataAsset.h"

