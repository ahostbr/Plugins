#pragma once

#include "CoreMinimal.h"
#include "GameplayTagContainer.h"
#include "SOTSFXTypes.generated.h"

class UNiagaraSystem;
class USoundBase;
class UAudioComponent;
class UNiagaraComponent;
class USceneComponent;
class AActor;

/**
 * Context used when requesting an FX cue.
 * This is what abilities / KEM / anything will build and pass in.
 */
USTRUCT(BlueprintType)
struct FSOTS_FXContext
{
    GENERATED_BODY()

    FSOTS_FXContext()
        : Location(FVector::ZeroVector)
        , Rotation(FRotator::ZeroRotator)
        , Scale(1.0f)
        , AttachComponent(nullptr)
        , Instigator(nullptr)
        , Target(nullptr)
        , bAttach(false)
        , bFollowRotation(false)
    {}

    // Where to spawn if not attaching
    UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "FX")
    FVector Location;

    UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "FX")
    FRotator Rotation;

    // Uniform scale for spawned FX
    UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "FX")
    float Scale;

    // Optional attachment
    UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "FX")
    USceneComponent* AttachComponent;

    UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "FX")
    FName AttachSocketName;

    UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "FX")
    bool bAttach;

    UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "FX")
    bool bFollowRotation;

    // Gameplay context – plain actors, nothing GAS-specific
    UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "FX")
    AActor* Instigator;

    UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "FX")
    AActor* Target;

    // Extra semantic info (surface, damage type, etc) for future expansion
    UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "FX")
    FGameplayTagContainer ExtraTags;
};

/**
 * Handle to spawned FX so you can stop / fade / debug later.
 */
USTRUCT(BlueprintType)
struct FSOTS_FXHandle
{
    GENERATED_BODY()

    UPROPERTY(BlueprintReadOnly, Category = "FX")
    TObjectPtr<UNiagaraComponent> NiagaraComponent = nullptr;

    UPROPERTY(BlueprintReadOnly, Category = "FX")
    TObjectPtr<UAudioComponent> AudioComponent = nullptr;

    UPROPERTY(BlueprintReadOnly, Category = "FX")
    FGameplayTag CueTag;
};

/**
 * Debug info about how many FX components are currently active.
 */
USTRUCT(BlueprintType)
struct FSOTS_FXActiveCounts
{
    GENERATED_BODY()

    // Number of Niagara components currently active
    UPROPERTY(BlueprintReadOnly, Category = "FX|Debug")
    int32 ActiveNiagara = 0;

    // Number of Audio components currently playing
    UPROPERTY(BlueprintReadOnly, Category = "FX|Debug")
    int32 ActiveAudio = 0;
};
