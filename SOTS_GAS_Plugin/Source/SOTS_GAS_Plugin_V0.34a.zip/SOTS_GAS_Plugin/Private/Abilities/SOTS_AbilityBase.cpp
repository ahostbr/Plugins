#include "Abilities/SOTS_AbilityBase.h"

#include "Components/SOTS_AbilityComponent.h"
#include "GameFramework/Actor.h"

void USOTS_AbilityBase::Initialize(UAC_SOTS_Abilitys* InComponent,
                                   const F_SOTS_AbilityDefinition& InDefinition,
                                   const F_SOTS_AbilityHandle& InHandle)
{
    OwningComponent = InComponent;
    OwningActor     = InComponent ? InComponent->GetOwner() : nullptr;
    AbilityTag      = InDefinition.AbilityTag;
    Handle          = InHandle;

    OnAbilityGranted(InDefinition);
}
