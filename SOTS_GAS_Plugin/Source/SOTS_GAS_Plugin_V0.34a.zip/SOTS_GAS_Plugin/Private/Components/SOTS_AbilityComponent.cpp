#include "Components/SOTS_AbilityComponent.h"

#include "Abilities/SOTS_AbilityBase.h"
#include "Subsystems/SOTS_AbilityRegistrySubsystem.h"
#include "Engine/World.h"
#include "GameFramework/Actor.h"

UAC_SOTS_Abilitys::UAC_SOTS_Abilitys()
{
    PrimaryComponentTick.bCanEverTick = false;
}

void UAC_SOTS_Abilitys::BeginPlay()
{
    Super::BeginPlay();
}

USOTS_AbilityRegistrySubsystem* UAC_SOTS_Abilitys::GetRegistry() const
{
    if (const UWorld* World = GetWorld())
    {
        if (UGameInstance* GI = World->GetGameInstance())
        {
            return GI->GetSubsystem<USOTS_AbilityRegistrySubsystem>();
        }
    }
    return nullptr;
}

bool UAC_SOTS_Abilitys::InternalGetDefinition(FGameplayTag AbilityTag, F_SOTS_AbilityDefinition& OutDef) const
{
    if (!AbilityTag.IsValid())
    {
        return false;
    }

    if (USOTS_AbilityRegistrySubsystem* Registry = GetRegistry())
    {
        return Registry->GetAbilityDefinitionByTag(AbilityTag, OutDef);
    }

    return false;
}

float UAC_SOTS_Abilitys::GetWorldTime() const
{
    const UWorld* World = GetWorld();
    return World ? World->GetTimeSeconds() : 0.0f;
}

bool UAC_SOTS_Abilitys::PassesOwnerTagGate(const F_SOTS_AbilityDefinition& /*Def*/) const
{
    // Hook into your global GameplayTag manager here if desired.
    return true;
}

bool UAC_SOTS_Abilitys::PassesSkillGate(const F_SOTS_AbilityDefinition& Def) const
{
    if (Def.SkillGateMode == E_SOTS_AbilitySkillGateMode::None || Def.RequiredSkillTags.Num() == 0)
    {
        return true;
    }

    AActor* OwnerActor = GetOwner();
    if (!OwnerActor)
    {
        return false;
    }

    if (!OwnerActor->GetClass()->ImplementsInterface(UBPI_SOTS_SkillTreeAccess::StaticClass()))
    {
        return false;
    }

    for (const FGameplayTag& SkillTag : Def.RequiredSkillTags)
    {
        const bool bUnlocked = IBPI_SOTS_SkillTreeAccess::Execute_IsSkillUnlocked(OwnerActor, SkillTag);
        if (!bUnlocked)
        {
            return false;
        }
    }

    return true;
}

int32 UAC_SOTS_Abilitys::QueryInventoryItemCount(const FGameplayTagContainer& Tags) const
{
    AActor* OwnerActor = GetOwner();
    if (!OwnerActor)
    {
        return 0;
    }

    if (!OwnerActor->GetClass()->ImplementsInterface(UBPI_SOTS_InventoryAccess::StaticClass()))
    {
        return 0;
    }

    return IBPI_SOTS_InventoryAccess::Execute_GetInventoryItemCountByTags(OwnerActor, Tags);
}

bool UAC_SOTS_Abilitys::ConsumeInventoryItems(const FGameplayTagContainer& Tags, int32 Count) const
{
    AActor* OwnerActor = GetOwner();
    if (!OwnerActor)
    {
        return false;
    }

    if (!OwnerActor->GetClass()->ImplementsInterface(UBPI_SOTS_InventoryAccess::StaticClass()))
    {
        return false;
    }

    return IBPI_SOTS_InventoryAccess::Execute_ConsumeInventoryItemsByTags(OwnerActor, Tags, Count);
}

bool UAC_SOTS_Abilitys::PassesInventoryGate(const F_SOTS_AbilityDefinition& Def) const
{
    if (Def.InventoryMode == E_SOTS_AbilityInventoryMode::None)
    {
        return true;
    }

    if (Def.RequiredInventoryTags.Num() == 0)
    {
        return true;
    }

    const int32 Count = QueryInventoryItemCount(Def.RequiredInventoryTags);
    return Count > 0;
}

bool UAC_SOTS_Abilitys::HasSufficientCharges(const F_SOTS_AbilityDefinition& Def) const
{
    const F_SOTS_AbilityRuntimeState* State = RuntimeStates.Find(Def.AbilityTag);

    switch (Def.ChargeMode)
    {
        case E_SOTS_AbilityChargeMode::InternalOnly:
        {
            // MaxCharges <= 0 means infinite uses
            if (Def.MaxCharges <= 0)
            {
                return true;
            }

            const int32 Internal = State ? State->CurrentCharges : Def.MaxCharges;
            return Internal > 0;
        }

        case E_SOTS_AbilityChargeMode::InventoryLinked:
        {
            const int32 Count = QueryInventoryItemCount(Def.RequiredInventoryTags);
            return Count > 0;
        }

        case E_SOTS_AbilityChargeMode::Hybrid:
        {
            const int32 InventoryCount = QueryInventoryItemCount(Def.RequiredInventoryTags);

            // MaxCharges <= 0 means infinite internal charges; only inventory gates us
            if (Def.MaxCharges <= 0)
            {
                return InventoryCount > 0;
            }

            const int32 InternalCharges = State ? State->CurrentCharges : Def.MaxCharges;
            return InternalCharges > 0 && InventoryCount > 0;
        }

        default:
            break;
    }

    return true;
}


void UAC_SOTS_Abilitys::ConsumeChargesOnActivation(const F_SOTS_AbilityDefinition& Def)
{
    F_SOTS_AbilityRuntimeState* State = RuntimeStates.Find(Def.AbilityTag);
    if (!State)
    {
        State = &RuntimeStates.FindOrAdd(Def.AbilityTag);
        State->Handle.AbilityTag = Def.AbilityTag;
        State->Handle.InternalId = NextInternalHandleId++;
        State->Handle.bIsValid   = true;

        // Initialise internal charges only if finite
        if (Def.ChargeMode == E_SOTS_AbilityChargeMode::InternalOnly ||
            Def.ChargeMode == E_SOTS_AbilityChargeMode::Hybrid)
        {
            if (Def.MaxCharges > 0)
            {
                State->CurrentCharges = Def.MaxCharges;
            }
        }
    }

    switch (Def.ChargeMode)
    {
        case E_SOTS_AbilityChargeMode::InternalOnly:
        {
            // Only decrement if finite
            if (Def.MaxCharges > 0 && State->CurrentCharges > 0)
            {
                --State->CurrentCharges;
            }
            break;
        }

        case E_SOTS_AbilityChargeMode::InventoryLinked:
        {
            if (Def.InventoryMode == E_SOTS_AbilityInventoryMode::RequireAndConsume)
            {
                ConsumeInventoryItems(Def.RequiredInventoryTags, 1);
            }
            break;
        }

        case E_SOTS_AbilityChargeMode::Hybrid:
        {
            // Finite internal + inventory
            if (Def.MaxCharges > 0 && State->CurrentCharges > 0)
            {
                --State->CurrentCharges;
            }

            if (Def.InventoryMode == E_SOTS_AbilityInventoryMode::RequireAndConsume)
            {
                ConsumeInventoryItems(Def.RequiredInventoryTags, 1);
            }
            break;
        }
    }

    // Cooldown still applies even if internal charges are infinite
    if (State)
    {
        const float WorldTime = GetWorldTime();
        const float Cooldown  = Def.CooldownSeconds;
        State->CooldownEndTime = (Cooldown > 0.0f ? WorldTime + Cooldown : 0.0f);
    }
}


bool UAC_SOTS_Abilitys::GrantAbility(FGameplayTag AbilityTag, const F_SOTS_AbilityGrantOptions& Options, F_SOTS_AbilityHandle& OutHandle)
{
    OutHandle = F_SOTS_AbilityHandle();

    F_SOTS_AbilityDefinition Def;
    if (!InternalGetDefinition(AbilityTag, Def))
    {
        return false;
    }

    // Skill-gate on grant if required
    if (Def.SkillGateMode == E_SOTS_AbilitySkillGateMode::RequireForGrant ||
        Def.SkillGateMode == E_SOTS_AbilitySkillGateMode::RequireForBoth)
    {
        if (!PassesSkillGate(Def))
        {
            return false;
        }
    }

    F_SOTS_AbilityRuntimeState& State = RuntimeStates.FindOrAdd(AbilityTag);
    if (!State.Handle.bIsValid)
    {
        State.Handle.AbilityTag = AbilityTag;
        State.Handle.InternalId = NextInternalHandleId++;
        State.Handle.bIsValid   = true;
    }

    // Only finite internal charges are stored here
    State.CurrentCharges = 0;
    if (Def.ChargeMode == E_SOTS_AbilityChargeMode::InternalOnly ||
        Def.ChargeMode == E_SOTS_AbilityChargeMode::Hybrid)
    {
        if (Def.MaxCharges > 0)
        {
            State.CurrentCharges = (Options.InitialCharges > 0 ? Options.InitialCharges : Def.MaxCharges);
        }
        // MaxCharges <= 0 => infinite; we leave CurrentCharges at 0 and ignore it in HasSufficientCharges
    }

    if (Options.bStartOnCooldown)
    {
        const float WorldTime = GetWorldTime();
        const float Cooldown  = (Options.OverrideCooldownSeconds >= 0.0f)
                                ? Options.OverrideCooldownSeconds
                                : Def.CooldownSeconds;

        State.CooldownEndTime = (Cooldown > 0.0f ? WorldTime + Cooldown : 0.0f);
    }
    else
    {
        State.CooldownEndTime = 0.0f;
    }

    OutHandle = State.Handle;

    // Instance the ability object
    if (Def.AbilityClass)
    {
        USOTS_AbilityBase* AbilityInstance = nullptr;
        if (USOTS_AbilityBase** Found = AbilityInstances.Find(AbilityTag))
        {
            AbilityInstance = *Found;
        }

        if (!AbilityInstance)
        {
            AbilityInstance = NewObject<USOTS_AbilityBase>(this, Def.AbilityClass);
            if (AbilityInstance)
            {
                AbilityInstances.Add(AbilityTag, AbilityInstance);
            }
        }

        if (AbilityInstance)
        {
            AbilityInstance->Initialize(this, Def, State.Handle);
        }
    }

    return true;
}


bool UAC_SOTS_Abilitys::RevokeAbilityByTag(FGameplayTag AbilityTag)
{
    if (USOTS_AbilityBase** Found = AbilityInstances.Find(AbilityTag))
    {
        if (USOTS_AbilityBase* Ability = *Found)
        {
            Ability->OnAbilityRemoved();
        }
        AbilityInstances.Remove(AbilityTag);
    }

    return RuntimeStates.Remove(AbilityTag) > 0;
}

bool UAC_SOTS_Abilitys::TryActivateAbilityByTag(FGameplayTag AbilityTag, const F_SOTS_AbilityActivationContext& Context, E_SOTS_AbilityActivationResult& OutResult)
{
    OutResult = E_SOTS_AbilityActivationResult::Failed_CustomCondition;

    F_SOTS_AbilityDefinition Def;
    if (!InternalGetDefinition(AbilityTag, Def))
    {
        return false;
    }

    F_SOTS_AbilityRuntimeState& State = RuntimeStates.FindOrAdd(AbilityTag);
    if (!State.Handle.bIsValid)
    {
        State.Handle.AbilityTag = AbilityTag;
        State.Handle.InternalId = NextInternalHandleId++;
        State.Handle.bIsValid = true;
    }

    const float WorldTime = GetWorldTime();
    if (State.CooldownEndTime > 0.0f && WorldTime < State.CooldownEndTime)
    {
        OutResult = E_SOTS_AbilityActivationResult::Failed_Cooldown;
        OnAbilityFailed.Broadcast(AbilityTag, OutResult);
        return false;
    }

    if (!HasSufficientCharges(Def))
    {
        OutResult = E_SOTS_AbilityActivationResult::Failed_ChgDepleted;
        OnAbilityFailed.Broadcast(AbilityTag, OutResult);
        return false;
    }

    if (!PassesOwnerTagGate(Def))
    {
        OutResult = E_SOTS_AbilityActivationResult::Failed_OwnerTags;
        OnAbilityFailed.Broadcast(AbilityTag, OutResult);
        return false;
    }

    if (Def.SkillGateMode == E_SOTS_AbilitySkillGateMode::RequireForActivate ||
        Def.SkillGateMode == E_SOTS_AbilitySkillGateMode::RequireForBoth)
    {
        if (!PassesSkillGate(Def))
        {
            OutResult = E_SOTS_AbilityActivationResult::Failed_SkillGate;
            OnAbilityFailed.Broadcast(AbilityTag, OutResult);
            return false;
        }
    }

    if (!PassesInventoryGate(Def))
    {
        OutResult = E_SOTS_AbilityActivationResult::Failed_InventoryGate;
        OnAbilityFailed.Broadcast(AbilityTag, OutResult);
        return false;
    }

    ConsumeChargesOnActivation(Def);

    State.bIsActive = true;
    OnAbilityActivated.Broadcast(AbilityTag, State.Handle);

    if (USOTS_AbilityBase** FoundAbility = AbilityInstances.Find(AbilityTag))
    {
        if (USOTS_AbilityBase* Ability = *FoundAbility)
        {
            Ability->K2_ActivateAbility(Context);
        }
    }

    OutResult = E_SOTS_AbilityActivationResult::Success;
    return true;
}

void UAC_SOTS_Abilitys::CancelAllAbilities()
{
    for (auto& Kvp : RuntimeStates)
    {
        const FGameplayTag& AbilityTag = Kvp.Key;
        F_SOTS_AbilityRuntimeState& State = Kvp.Value;

        if (State.bIsActive)
        {
            State.bIsActive = false;

            if (USOTS_AbilityBase** FoundAbility = AbilityInstances.Find(AbilityTag))
            {
                if (USOTS_AbilityBase* Ability = *FoundAbility)
                {
                    Ability->K2_EndAbility();
                }
            }

            OnAbilityEnded.Broadcast(AbilityTag, State.Handle);
        }
    }
}

void UAC_SOTS_Abilitys::GetAbilityCharges(FGameplayTag AbilityTag, int32& OutCurrentCharges, int32& OutMaxCharges) const
{
    OutCurrentCharges = 0;
    OutMaxCharges     = 0;

    F_SOTS_AbilityDefinition Def;
    if (!const_cast<UAC_SOTS_Abilitys*>(this)->InternalGetDefinition(AbilityTag, Def))
    {
        return;
    }

    const F_SOTS_AbilityRuntimeState* State = RuntimeStates.Find(AbilityTag);

    switch (Def.ChargeMode)
    {
        case E_SOTS_AbilityChargeMode::InternalOnly:
        {
            if (Def.MaxCharges <= 0)
            {
                // Infinite: UI can treat Max <= 0 as ∞
                OutCurrentCharges = 0;
                OutMaxCharges     = 0;
            }
            else
            {
                const int32 Internal = State ? State->CurrentCharges : Def.MaxCharges;
                OutCurrentCharges    = Internal;
                OutMaxCharges        = Def.MaxCharges;
            }
            break;
        }

        case E_SOTS_AbilityChargeMode::InventoryLinked:
        {
            const int32 Count = QueryInventoryItemCount(Def.RequiredInventoryTags);
            OutCurrentCharges = Count;
            OutMaxCharges     = Count;
            break;
        }

        case E_SOTS_AbilityChargeMode::Hybrid:
        {
            const int32 Count    = QueryInventoryItemCount(Def.RequiredInventoryTags);
            const int32 Internal = (Def.MaxCharges > 0)
                                   ? (State ? State->CurrentCharges : Def.MaxCharges)
                                   : INT32_MAX; // treat internal as infinite if MaxCharges <= 0

            const int32 Effective = FMath::Min(Internal, Count);

            OutCurrentCharges = Effective;
            OutMaxCharges     = (Def.MaxCharges > 0 ? Def.MaxCharges : Count);
            break;
        }
    }
}


void UAC_SOTS_Abilitys::IsAbilityOnCooldown(FGameplayTag AbilityTag, bool& bOutIsOnCooldown, float& OutRemainingTime) const
{
    bOutIsOnCooldown = false;
    OutRemainingTime = 0.0f;

    const F_SOTS_AbilityRuntimeState* State = RuntimeStates.Find(AbilityTag);
    if (!State)
    {
        return;
    }

    const float WorldTime = GetWorldTime();
    if (State->CooldownEndTime > 0.0f && WorldTime < State->CooldownEndTime)
    {
        bOutIsOnCooldown = true;
        OutRemainingTime = State->CooldownEndTime - WorldTime;
    }
}
