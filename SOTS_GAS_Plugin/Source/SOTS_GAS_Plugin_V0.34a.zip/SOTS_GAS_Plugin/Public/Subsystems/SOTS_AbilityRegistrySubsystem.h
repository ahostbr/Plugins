#pragma once

#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "Data/SOTS_AbilityTypes.h"
#include "Data/SOTS_AbilityDataAssets.h"
#include "SOTS_AbilityRegistrySubsystem.generated.h"

UCLASS()
class SOTS_GAS_PLUGIN_API USOTS_AbilityRegistrySubsystem : public UGameInstanceSubsystem
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, Category="SOTS Ability|Registry")
    void RegisterAbilityDefinition(const F_SOTS_AbilityDefinition& Definition);

    UFUNCTION(BlueprintCallable, Category="SOTS Ability|Registry")
    void RegisterAbilityDefinitionDA(USOTS_AbilityDefinitionDA* DefinitionDA);

    UFUNCTION(BlueprintCallable, Category="SOTS Ability|Registry")
    void RegisterAbilityDefinitionsFromArray(const TArray<USOTS_AbilityDefinitionDA*>& Definitions);

    UFUNCTION(BlueprintCallable, Category="SOTS Ability|Registry")
    bool GetAbilityDefinitionByTag(FGameplayTag AbilityTag, F_SOTS_AbilityDefinition& OutDefinition) const;

    UFUNCTION(BlueprintCallable, Category="SOTS Ability|Registry")
    bool GetAbilityDefinitionDAByTag(FGameplayTag AbilityTag, USOTS_AbilityDefinitionDA*& OutDefinitionDA) const;

    UFUNCTION(BlueprintCallable, Category="SOTS Ability|Registry")
    void GetAllAbilityDefinitions(TArray<F_SOTS_AbilityDefinition>& OutDefinitions) const;

protected:
    UPROPERTY()
    TMap<FGameplayTag, F_SOTS_AbilityDefinition> AbilityDefinitions;

    UPROPERTY()
    TMap<FGameplayTag, USOTS_AbilityDefinitionDA*> AbilityDefinitionAssets;
};
