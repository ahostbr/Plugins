#pragma once

#include "CoreMinimal.h"
#include "GameplayTagContainer.h"
#include "SOTS_AbilityTypes.generated.h"

class AActor;
class USOTS_AbilityBase;

UENUM(BlueprintType)
enum class E_SOTS_AbilityActivationResult : uint8
{
    Success,
    Failed_Cooldown,
    Failed_ChgDepleted,
    Failed_InventoryGate,
    Failed_OwnerTags,
    Failed_SkillGate,
    Failed_CustomCondition
};

UENUM(BlueprintType)
enum class E_SOTS_AbilityInventoryMode : uint8
{
    None,
    RequireAndConsume,
    RequireOnly
};

UENUM(BlueprintType)
enum class E_SOTS_AbilityChargeMode : uint8
{
    InternalOnly,
    InventoryLinked,
    Hybrid
};

UENUM(BlueprintType)
enum class E_SOTS_AbilitySkillGateMode : uint8
{
    None,
    RequireForGrant,
    RequireForActivate,
    RequireForBoth
};

UENUM(BlueprintType)
enum class E_SOTS_AbilityActivationPolicy : uint8
{
    OnInputPressed,
    OnInputReleased,
    OnOwnerEvent,
    Passive
};

USTRUCT(BlueprintType)
struct SOTS_GAS_PLUGIN_API F_SOTS_AbilityHandle
{
    GENERATED_BODY()

public:
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 InternalId = INDEX_NONE;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FGameplayTag AbilityTag;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    bool bIsValid = false;
};

USTRUCT(BlueprintType)
struct SOTS_GAS_PLUGIN_API F_SOTS_AbilityGrantOptions
{
    GENERATED_BODY()

public:
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 InitialCharges = 0;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    bool bStartOnCooldown = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float OverrideCooldownSeconds = -1.0f;
};

USTRUCT(BlueprintType)
struct SOTS_GAS_PLUGIN_API F_SOTS_AbilityActivationContext
{
    GENERATED_BODY()

public:
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    AActor* Instigator = nullptr;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    AActor* TargetActor = nullptr;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FVector TargetLocation = FVector::ZeroVector;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FGameplayTagContainer ActivationTags;
};

USTRUCT(BlueprintType)
struct SOTS_GAS_PLUGIN_API F_SOTS_AbilityDefinition
{
    GENERATED_BODY()

public:
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Ability")
    FGameplayTag AbilityTag;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Ability")
    TSubclassOf<USOTS_AbilityBase> AbilityClass;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Ability")
    float CooldownSeconds = 0.0f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Ability")
    int32 MaxCharges = 0;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Ability")
    E_SOTS_AbilityChargeMode ChargeMode = E_SOTS_AbilityChargeMode::InternalOnly;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Ability")
    E_SOTS_AbilityInventoryMode InventoryMode = E_SOTS_AbilityInventoryMode::None;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Ability")
    E_SOTS_AbilitySkillGateMode SkillGateMode = E_SOTS_AbilitySkillGateMode::None;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Ability")
    FGameplayTagContainer RequiredOwnerTags;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Ability")
    FGameplayTagContainer BlockedOwnerTags;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Ability")
    FGameplayTagContainer RequiredInventoryTags;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Ability")
    TArray<FGameplayTag> RequiredSkillTags;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Ability")
    FGameplayTagContainer GrantedTagsWhileActive;
};

USTRUCT()
struct F_SOTS_AbilityRuntimeState
{
    GENERATED_BODY()

public:
    UPROPERTY()
    F_SOTS_AbilityHandle Handle;

    UPROPERTY()
    bool bIsActive = false;

    UPROPERTY()
    int32 CurrentCharges = 0;

    UPROPERTY()
    float CooldownEndTime = 0.0f;
};
