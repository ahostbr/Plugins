#pragma once

#include "Modules/ModuleManager.h"

class FSOTS_GAS_PluginModule : public IModuleInterface
{
public:
    virtual void StartupModule() override;
    virtual void ShutdownModule() override;
};
