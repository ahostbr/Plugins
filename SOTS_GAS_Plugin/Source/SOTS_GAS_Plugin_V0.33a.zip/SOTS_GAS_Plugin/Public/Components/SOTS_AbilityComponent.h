#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "GameplayTagContainer.h"
#include "Data/SOTS_AbilityTypes.h"
#include "Interfaces/SOTS_AbilityInterfaces.h"
#include "SOTS_AbilityComponent.generated.h"

class USOTS_AbilityRegistrySubsystem;
class USOTS_AbilityBase;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FSOTS_AbilitySimpleSignature, FGameplayTag, AbilityTag, F_SOTS_AbilityHandle, Handle);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FSOTS_AbilityFailedSignature, FGameplayTag, AbilityTag, E_SOTS_AbilityActivationResult, Result);

UCLASS(ClassGroup=(SOTS), meta=(BlueprintSpawnableComponent))
class SOTS_GAS_PLUGIN_API UAC_SOTS_Abilitys : public UActorComponent
{
    GENERATED_BODY()

public:
    UAC_SOTS_Abilitys();

    UPROPERTY(BlueprintAssignable, Category="SOTS Ability|Events")
    FSOTS_AbilitySimpleSignature OnAbilityActivated;

    UPROPERTY(BlueprintAssignable, Category="SOTS Ability|Events")
    FSOTS_AbilitySimpleSignature OnAbilityEnded;

    UPROPERTY(BlueprintAssignable, Category="SOTS Ability|Events")
    FSOTS_AbilityFailedSignature OnAbilityFailed;

    UFUNCTION(BlueprintCallable, Category="SOTS Ability")
    bool GrantAbility(FGameplayTag AbilityTag, const F_SOTS_AbilityGrantOptions& Options, F_SOTS_AbilityHandle& OutHandle);

    UFUNCTION(BlueprintCallable, Category="SOTS Ability")
    bool RevokeAbilityByTag(FGameplayTag AbilityTag);

    UFUNCTION(BlueprintCallable, Category="SOTS Ability")
    bool TryActivateAbilityByTag(FGameplayTag AbilityTag, const F_SOTS_AbilityActivationContext& Context, E_SOTS_AbilityActivationResult& OutResult);

    UFUNCTION(BlueprintCallable, Category="SOTS Ability")
    void CancelAllAbilities();

    UFUNCTION(BlueprintCallable, Category="SOTS Ability|Query")
    void GetAbilityCharges(FGameplayTag AbilityTag, int32& OutCurrentCharges, int32& OutMaxCharges) const;

    UFUNCTION(BlueprintCallable, Category="SOTS Ability|Query")
    void IsAbilityOnCooldown(FGameplayTag AbilityTag, bool& bOutIsOnCooldown, float& OutRemainingTime) const;

protected:
    virtual void BeginPlay() override;

    USOTS_AbilityRegistrySubsystem* GetRegistry() const;

    bool InternalGetDefinition(FGameplayTag AbilityTag, F_SOTS_AbilityDefinition& OutDef) const;

    bool PassesOwnerTagGate(const F_SOTS_AbilityDefinition& Def) const;
    bool PassesSkillGate(const F_SOTS_AbilityDefinition& Def) const;
    bool PassesInventoryGate(const F_SOTS_AbilityDefinition& Def) const;

    bool HasSufficientCharges(const F_SOTS_AbilityDefinition& Def) const;
    void ConsumeChargesOnActivation(const F_SOTS_AbilityDefinition& Def);

    int32 QueryInventoryItemCount(const FGameplayTagContainer& Tags) const;
    bool ConsumeInventoryItems(const FGameplayTagContainer& Tags, int32 Count) const;

    float GetWorldTime() const;

protected:
    UPROPERTY()
    TMap<FGameplayTag, F_SOTS_AbilityRuntimeState> RuntimeStates;

    UPROPERTY()
    TMap<FGameplayTag, USOTS_AbilityBase*> AbilityInstances;

    UPROPERTY()
    int32 NextInternalHandleId = 1;
};
