#include "Subsystems/SOTS_AbilityRegistrySubsystem.h"

void USOTS_AbilityRegistrySubsystem::RegisterAbilityDefinition(const F_SOTS_AbilityDefinition& Definition)
{
    if (!Definition.AbilityTag.IsValid())
    {
        return;
    }

    AbilityDefinitions.FindOrAdd(Definition.AbilityTag) = Definition;
}

void USOTS_AbilityRegistrySubsystem::RegisterAbilityDefinitionDA(USOTS_AbilityDefinitionDA* DefinitionDA)
{
    if (!DefinitionDA)
    {
        return;
    }

    const F_SOTS_AbilityDefinition& Def = DefinitionDA->Ability;
    if (!Def.AbilityTag.IsValid())
    {
        return;
    }

    AbilityDefinitions.FindOrAdd(Def.AbilityTag) = Def;
    AbilityDefinitionAssets.FindOrAdd(Def.AbilityTag) = DefinitionDA;
}

void USOTS_AbilityRegistrySubsystem::RegisterAbilityDefinitionsFromArray(const TArray<USOTS_AbilityDefinitionDA*>& Definitions)
{
    for (USOTS_AbilityDefinitionDA* DA : Definitions)
    {
        RegisterAbilityDefinitionDA(DA);
    }
}

bool USOTS_AbilityRegistrySubsystem::GetAbilityDefinitionByTag(FGameplayTag AbilityTag, F_SOTS_AbilityDefinition& OutDefinition) const
{
    if (const F_SOTS_AbilityDefinition* Found = AbilityDefinitions.Find(AbilityTag))
    {
        OutDefinition = *Found;
        return true;
    }
    return false;
}

bool USOTS_AbilityRegistrySubsystem::GetAbilityDefinitionDAByTag(FGameplayTag AbilityTag, USOTS_AbilityDefinitionDA*& OutDefinitionDA) const
{
    if (USOTS_AbilityDefinitionDA* const* Found = AbilityDefinitionAssets.Find(AbilityTag))
    {
        OutDefinitionDA = *Found;
        return true;
    }
    return false;
}

void USOTS_AbilityRegistrySubsystem::GetAllAbilityDefinitions(TArray<F_SOTS_AbilityDefinition>& OutDefinitions) const
{
    OutDefinitions.Reset();
    for (const auto& Kvp : AbilityDefinitions)
    {
        OutDefinitions.Add(Kvp.Value);
    }
}
